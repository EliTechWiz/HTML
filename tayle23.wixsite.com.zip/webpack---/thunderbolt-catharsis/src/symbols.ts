export const CatharsisMegaStoreSymbol = Symbol('CatharsisMegaStore')
export const CatharsisSymbol = Symbol('CatharsisSymbol')
