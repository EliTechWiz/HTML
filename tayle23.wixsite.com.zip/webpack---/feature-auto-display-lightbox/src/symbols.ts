export const AutoDisplayLightboxSymbol = Symbol('AutoDisplayLightbox')

export const name = 'autoDisplayLightbox' as const
