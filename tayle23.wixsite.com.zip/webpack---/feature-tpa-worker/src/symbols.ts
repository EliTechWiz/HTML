export const name = 'tpaWorkerFeature' as const
export const TpaWorkerSymbol = Symbol('TpaWorker')
