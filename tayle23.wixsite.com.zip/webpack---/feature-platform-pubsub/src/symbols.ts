export const PlatformPubsubSymbol = Symbol('platformPubsub')
export const name = 'platformPubsub' as const
