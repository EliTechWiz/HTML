export const isPartyTownSupported = () => 'partytown' in window;
